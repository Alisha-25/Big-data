#!/usr/bin/python

import os
import sys
os.environ["SPARK_HOME"] = "/home/talentum/spark"
os.environ["PYLIB"] = os.environ["SPARK_HOME"] + "/python/lib"
os.environ["PYSPARK_PYTHON"] = "/usr/bin/python3.6" 
os.environ["PYSPARK_DRIVER_PYTHON"] = "/usr/bin/python3"
sys.path.insert(0, os.environ["PYLIB"] +"/py4j-0.10.7-src.zip")
sys.path.insert(0, os.environ["PYLIB"] +"/pyspark.zip")
os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages com.databricks:spark-xml_2.11:0.6.0,org.apache.spark:spark-avro_2.11:2.4.3 pyspark-shell'

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()
sc = spark.sparkContext

filepath = "whitehouse_visits.txt"

potusRDD = sc.textFile(filepath)\
.filter(lambda line: line.split(',')[19]=='POTUS')

print(potusRDD.take(5))

project_potusRDD = potusRDD.map(lambda line: 
                               (line.split(',')[0],
                               line.split(',')[1],
                                line.split(',')[6],
                                line.split(',')[11],
                                line.split(',')[21],
                                line.split(',')[25]
                               ))
project_potusRDD.saveAsTextFile("/user/hive/warehouse/wh_visits_spark_1")

for line in project_potusRDD.take(10):
    print(line)





