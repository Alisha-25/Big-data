#!/bin/bash

#Putting counties folder and its files into hdfs
hdfs dfs -put -f /home/cloudera/shared/Average/counties
echo "file transfer to hdfs counties"

#Creating output folder in hdfs
hdfs dfs -test -d /home/cloudera/average
if [ $? == 0 ]
then
	hdfs dfs -rm -R /home/cloudera/average
	echo "/home/cloudera/average deleted from hdfs"
	hdfs dfs -mkdir /home/cloudera/average
	echo "/home/cloudera/average is created in hdfs"
else
	hdfs dfs -mkdir /home/cloudera/average
	echo "/home/cloudera/average is created in hdfs"
fi

echo "created output folder '/home/cloudera/average' in hdfs"

#Create folder in local m/c to keep .java file and .jar file
cd /home/cloudera/hdp/pigandhive/labs/
if [ -d mrlab_prob2 ]
then
	rm -r mrlab_prob2
	echo "mrlab_prob2 is deleted"
	mkdir mrlab_prob2
	echo "mrlab_prob2 is created"
else
	mkdir mrlab_prob2
	echo "mrlab_prob2 is created"
fi
cd mrlab_prob2/

#Move the main class file from project to mrlab_prob2 folder
cp /home/cloudera/workspace/evalab3/src/average/AverageJob.java .
echo "file moved ................."

#Create and verify jar
#jar -cvf a2.jar /home/cloudera/workspace_1/averagejob/bin/average/*
jar -cvf a2.jar /home/cloudera/workspace/evalab3/bin/average/*
ls -lh
echo "jar is created"


#Run the jar
echo "Verify jar..............."
jar -tf a2.jar
echo ""
echo "Running jar ............."
#yarn jar a2.jar average.AverageJob
yarn jar a2.jar /home/cloudera/workspace/evalab3/bin/average.AverageJob
echo "jar run completed"

#Output
hdfs dfs -cat average/part-r-0000*
