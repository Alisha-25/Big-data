#!/bin/bash

hive -f ddl.hive -hivevar nt=Business -hivevar dt=Branch
hive -f load.hive -hivevar nt=Business -hivevar dt=Branch
hive -f query.hive -hivevar nt=Business -hivevar dt=Branch
