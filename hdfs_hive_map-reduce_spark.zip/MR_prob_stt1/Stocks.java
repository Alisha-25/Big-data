package stockpack;

import java.io.IOException;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class Stocks extends Configured implements Tool {

	public static class StockVolumeMapper extends
			Mapper<LongWritable, Text, Text, LongWritable> {
		private final static LongWritable volume = new LongWritable();
		private Text stockSymbol = new Text();
		private boolean header = true;

		@Override
		protected void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {

			if (header) {
				header = false;
				return;
			}

			String[] fields = value.toString().split(",");
			String symbol = fields[1];
			long stockVolume = Long.parseLong(fields[7]);

			stockSymbol.set(symbol);
			volume.set(stockVolume);

			context.write(stockSymbol, volume);
		}

	}

	public static class StockVolumeReducer extends
			Reducer<Text, LongWritable, Text, LongWritable> {

		private LongWritable result = new LongWritable();

		@Override
		protected void reduce(Text key, Iterable<LongWritable> values,
				Context context) throws IOException, InterruptedException {
			long sum = 0;
			long count = 0;

			for (LongWritable val : values) {
				sum += val.get();
				count++;
			}

			long average = sum / count;
			result.set(average);

			context.write(key, result);
		}
	}

	@Override
	public int run(String[] args) throws Exception {
		Configuration conf = super.getConf();
		Job job = Job.getInstance(conf, "StockJob");
		job.setJarByClass(Stocks.class);

		Path in = new Path(args[0]);
		Path out = new Path(args[1]);
		out.getFileSystem(conf).delete(out, true);
		FileInputFormat.setInputPaths(job, in);
		FileOutputFormat.setOutputPath(job, out);

		// TODO
		job.setMapperClass(StockVolumeMapper.class);
		// TODO
		job.setReducerClass(StockVolumeReducer.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		// TODO
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(LongWritable.class);
		// TODO
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(LongWritable.class);

		return job.waitForCompletion(true) ? 0 : 1;
	}

	public static void main(String[] args) {
		int result;
		try {
			// TODO
			result = ToolRunner.run(new Configuration(), new Stocks(), args);
			System.exit(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
