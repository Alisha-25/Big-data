#!/bin/bash
source unset.sh
spark-submit hortonworks.py
