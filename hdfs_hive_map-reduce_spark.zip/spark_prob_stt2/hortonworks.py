#!/usr/bin/python
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()
sc = spark.sparkContext
print("----------------------------------------------------------------")
filepath = "file:///home/talentum/test-jupyter/LABS/prob_stt_2/hortonworks.txt"
rdd = sc.textFile(filepath)
rdd.take(5)
print("----------------------------------------------------------------")
rdd1 = rdd.map(lambda x: x.split(','))
rdd1.collect()
print("----------------------------------------------------------------")
l1 = []
for i in rdd1.collect():
    for j in range(1, len(i)):
        l1.append((i[j], i[0]))
print(l1)
print("----------------------------------------------------------------")
rdd2 = sc.parallelize(l1)
rdd2.take(5)
print("----------------------------------------------------------------")
rdd3 = rdd2.reduceByKey(lambda x,y: x+","+y).sortByKey()
rdd3.take(5)
print("----------------------------------------------------------------")
for i in rdd3.collect():
    print(i[0]+" "+i[1])
print("----------------------------------------------------------------")

