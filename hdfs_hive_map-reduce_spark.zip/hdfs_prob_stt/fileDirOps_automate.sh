#!/bin/bash
# Author: Dhavale Alisha Satish
# Creation on: 02-06-2024
# Modification date: 06-06-2024 
# Description: It create & delete directory, upload & delete file, merge files in hdfs , and much more.........


while [ "$ch" != 0 ]
do
echo "  "
echo "1. Create a directory 2. Delete a directory 3. Upload a file 4. Delete a file 5. Merge files in hdfs and save in a directory 6. To see files and directories in HDFS 7. To create a block of merged file 0.Exit"
echo " "
read -p "Enter your choice:" ch
case $ch in
	1)
		echo "------create a directory-------"
		read -p "Enter directory name: " dname
		echo "------creating directory-------"
		hdfs dfs -mkdir $dname
		echo "------view directory in hdfs------"
		hdfs dfs -ls
	;;
	2)
	  	echo "------delete a directory-------"
                read -p "Enter directory name: " dname
                echo "------checking directory in HDFS-------"
                if hdfs dfs -test -d $dname
		then
			echo "----directory found-----"
			echo "----deleting directory----"
			hdfs dfs -rm -r	$dname
			echo "----directory deleted----"
			echo "------view directory in hdfs------"
	                hdfs dfs -ls
        	        echo "------directory deleted successfully-------"
                else
			echo "----directory not found----"
		fi
	;;
	3)
	  	echo "------Upload a file-------"
                read -p "Enter file name: " fname
		if hdfs dfs -test -f $fname
		then
			echo "----file already exists in HDFS----"
			hdfs dfs -ls
		else
			read -p "Enter local path of file: " lpath
                	echo "------uploading file-------"
			cd $lpath
                	hdfs dfs -put $fname
			echo "----file uploaded----"
               		echo "------view file in hdfs------"
                	hdfs dfs -ls
			echo "----file uploaded successfully----"
		fi
	;;
	4)
	  	echo "------Delete a file-------"
                read -p "Enter file name: " fname
                if hdfs dfs -test -f $fname
		then
			echo "----file exists in HDFS----"
                        hdfs dfs -ls
			echo "----deleting file----"
			hdfs dfs -rm $fname
			echo "----file deleted-----"
			hdfs dfs -ls
			echo "----file deleted successfully----"
		else
			echo "----file not found in HDFS----"
			hdfs dfs -ls
		fi
	;;
	5)
	  	echo "------Merge files in hdfs and save in a directory-------"
		hdfs dfs -ls
                read -p "Enter directory name from HDFS whose all files you have to merge: " dname
		read -p "Enter name of the file that you want for merged file: " fname
                read -p "Enter local path of the directory where you need the merge file to get stored: " lpath
		echo "------merging all the files in the specified directory-------"
                hdfs dfs -getmerge $dname $path/$name
		echo "-----files are merged successfully-----"
                echo "------view merged file in directory ------"
                cd $lpath
		echo "----merged file is saved here----"
		echo $lpath
		ls
	;;
	6)
	  	echo "------To see files and directories in HDFS-------"
                hdfs dfs -ls
	;;
	7)
          	echo "------To create a block of merged file-------"
                read -p "Enter file name: " file
		if hdfs dfs -test -f $file
		then
			echo "-----file exists in hdfs-----"
			hdfs fsck /user/cloudera/$file -files -blocks-locations
			echo "------blocks created for this file------"
		else
			hdfs dfs -ls
                	echo "-----file doesn't exist in hdfs-----"
			read -p "Enter directory name from HDFS whose all files you have to merge: " dname
                	read -p "Enter name of the file that you want for merged file: " fname
                	read -p "Enter local path of the directory where you need the merge file to get stored: " lpath
                	echo "------merging all the files in the specified directory-------"
                	hdfs dfs -getmerge $dname $path/$name
                	echo "-----files are merged successfully-----"
                	echo "------view merged file in directory ------"
                	cd $lpath
                	echo "----merged file is saved here----"
                	echo $lpath
                	ls
			hdfs fsck /user/cloudera/$fname -files -blocks -locations
                        echo "------blocks created for the merged file------"
		fi
                
        ;;

	*)
		ch=0
	;;
esac
done


