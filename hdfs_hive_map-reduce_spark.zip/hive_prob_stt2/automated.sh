#!/bin/bash

echo "SimpleSerde"

hive -f ddl_SimpleSerde.hive 
hive -f load.hive

echo " "
echo "In the csv file our 3rd column has two value whih are comma seperated so our SimpleSerde fails"
echo "So we use OpenCSVSerde"

echo " "

echo "OpenCSVSerde"

hive -f ddl.hive
hive -f load.hive
hive -f query.hive
