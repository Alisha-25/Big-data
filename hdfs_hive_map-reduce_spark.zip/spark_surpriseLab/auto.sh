#!/bin/bash

#bash hdf.sh

if hdfs dfs -test -e /user/talentum/Complete_Shakespeare.txt
then
hdfs dfs -rm Complete_Shakespeare.txt
fi

hdfs dfs -put Complete_Shakespeare.txt

source unset.sh

spark-submit WordCount.py
