#!/usr/bin/python


import os
import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
# from pyspark.sql import SaveMode
# from pyspark.sql import HiveContext


os.environ["SPARK_HOME"] = "/home/talentum/spark"
os.environ["PYLIB"] = os.environ["SPARK_HOME"] + "/python/lib"
# In below two lines, use /usr/bin/python2.7 if you want to use Python 2
os.environ["PYSPARK_PYTHON"] = "/usr/bin/python3.6" 
os.environ["PYSPARK_DRIVER_PYTHON"] = "/usr/bin/python3"
sys.path.insert(0, os.environ["PYLIB"] +"/py4j-0.10.7-src.zip")
sys.path.insert(0, os.environ["PYLIB"] +"/pyspark.zip")

# NOTE: Whichever package you want mention here.
# os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages com.databricks:spark-xml_2.11:0.6.0 pyspark-shell' 
# os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages org.apache.spark:spark-avro_2.11:2.4.0 pyspark-shell'
os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages com.databricks:spark-xml_2.11:0.6.0,org.apache.spark:spark-avro_2.11:2.4.3 pyspark-shell'
# os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages com.databricks:spark-xml_2.11:0.6.0,org.apache.spark:spark-avro_2.11:2.4.0 pyspark-shell'


spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()
# sc = spark.sparkContext
# Declaing stop words list
stop_words = ['','i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'can', 'will', 'just', 'don', 'should', 'now']
df = spark.read.format('text').load("file:////home/talentum/test-jupyter/P2/M1/SM4/Dataset/Complete_Shakespeare.txt")

#df.show(truncate=False)

# Creating a Arr_words column having arrays of words line by line
#df = df.withColumn('Arr_words',F.split(df.value," "))
# Exploding the value to words
df = df.withColumn('words',F.explode(F.split(df.value," ")))
# Filtering the stop words
df = df.filter(~ F.lower(df.words).isin(stop_words))
#droping unnecessary columns and counting the words
df = df.drop('Arr_words','value').groupby('words').count().sort('count', ascending=False)

#variables for jdbc connectivity
url = "jdbc:mysql://127.0.0.1:3306/test?useSSL=false&allowPublicKeyRetrieval=true"
driver = "com.mysql.jdbc.Driver"
user = "bigdata"
password = "Bigdata@123"


# #creating a table with name "wrd"
# df.write \
#     .mode('overwrite')\
#     .option("createTableColumnTypes", "words TEXT, count BIGINT") \
#     .jdbc(url,"wrd",properties={"user": user, "password": password})



# sqlContext = HiveContext(sc)
# spark.sql('drop table WordCount')
# Creating a table WordCount in mysql Make sure the table WordCount does not exist on Mysql
df.write\
    .mode('overwrite')\
    .format("jdbc")\
    .option("driver", driver)\
    .option("url", url)\
    .option("user", user)\
    .option("password", password)\
    .option("dbtable", "WordCount")\
    .option('truncate',True)\
    .save()

# Loading the table into wrd
wrd =spark.read\
    .format("jdbc")\
    .option("driver", driver)\
    .option("url", url)\
    .option("user", user)\
    .option("password", password)\
    .option("dbtable", "WordCount")\
    .load()


# Executing query
spark.read.format("jdbc")\
     .option("url", url)\
     .option("query", "select * from WordCount where count > 200")\
     .option("user", user)\
     .option("password", password)\
     .load().show()
