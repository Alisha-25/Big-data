read -p "want to stop hdfs y or n?" choice

if [ $choice == 'y' ]
then
	cd /home/talentum/
	echo "Stopping..."
	./run-yarn.sh -s stop
	./run-hdfs.sh -s stop
else
	cd /home/talentum/
	echo "Starting..."
	hdfs namenode -format
	./run-hdfs.sh -s start
	./run-yarn.sh -s start
	hdfs dfs -mkdir -p /user/talentum/
	hdfs dfs -ls
fi
