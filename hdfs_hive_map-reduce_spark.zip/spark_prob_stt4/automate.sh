#!/bin/bash
hive -f drop.hive
unset PYSPARK_DRIVER_PYTHON
unset PYSPARK_DRIVER_PYTHON_OPTS
spark-submit EVP.py
