#!/usr/bin/python
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()
sc = spark.sparkContext
import pyspark.sql.functions as F
filepath = "file:///home/talentum/test-jupyter/LABS/prob_stt_4/Electric_Vehicle_Population_Data_LabExam.csv"
inputDF = spark.read.csv(filepath, header=True, inferSchema=True)
inputDF.createOrReplaceTempView("EVPOP")
# 1. Find the City with most number of “Battery Electric Vehicle (BEV)”.
q1 = 'select city, count(city) as Battery_EV_count from EVPOP where `Electric Vehicle Type` like "%Battery%" group by city order by count(city) desc limit 1'
spark.sql(q1).show()
# 2. Find the Car with highest “Electric_Range”
q2 = 'select distinct make, model, `VIN (1-10)`, electric_range from EVPOP order by electric_range desc limit 1'
spark.sql(q2).show()
# 3. Find the “Make” and “Model” type of car is most bought in area with “Postal Code” = “98126”
q3 = 'select make, model, count(make, model) as most_brought_in_area from EVPOP where postal_code = 98126 group by make, model'
spark.sql(q3).show()
# 4. Find which year had max cars with “CAFV_Eligibility” value = “Not eligible due to low battery range”
q4 = 'select `model year`, count(`model year`) as no_of_cars from EVPOP where CAFV_Eligibility == "Not eligible due to low battery range" group by `model year` order by no_of_cars desc limit 1'
spark.sql(q4).show()
# 5. Find which “Tesla”, “Model S” has the max “Electric Range”
q5 = 'select distinct make, model, electric_range from EVPOP order by electric_range desc limit 1'
spark.sql(q5).show()
# 6. Store the DataFrame into a Hive table by selecting County, City, State, Make, Model, Electric Vehicle Type 
# into Hive Table EVMS_US with partitioning done on columns State, City and County.
inputDF = inputDF.withColumnRenamed('Electric Vehicle Type', 'Electric_Vehicle_Type')
inputDF = inputDF.select('make', 'model', inputDF['Electric_Vehicle_Type'], 'state', 'city', 'county')
# 7. Which format you will use to store the data into Hive table if performance is the criteria.
inputDF.write.format('parquet').partitionBy("State","city","county").saveAsTable("EVM_US")


