#!/usr/bin/python
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()
sc = spark.sparkContext
import pyspark.sql.types
from pyspark.sql.types import StructType, StructField, StringType
filepath = "file:///home/talentum/test-jupyter/LABS/prob_stt_3/whitehouse_visits.txt"
rdd = sc.textFile(filepath)
rdd1 = rdd.map(lambda line: line.split(','))
print(rdd1.take(5))
rdd2 = rdd1.filter(lambda x: x[19]=='POTUS')
print(rdd2.take(5))
rdd3 = rdd2.map(lambda col: (col[0],col[1],col[6],col[11],col[21],col[25]))
print(rdd3.take(5))
rdd4 = rdd3.map(lambda x: ','.join(x))
print(rdd4.take(5))
wh_schema = StructType([StructField('lname',StringType(),True),
                    StructField('fname',StringType(),True),
                    StructField('time_of_travel',StringType(),True),
                    StructField('appt_schedule_time',StringType(),True),
                    StructField('location',StringType(),True),
                    StructField('comment',StringType(),True)])
potus_proj = spark.createDataFrame(rdd3, schema = wh_schema)
print(potus_proj.printSchema())
potus_proj.show(5)
potus_proj.write.format("parquet").mode('overwrite').saveAsTable('potus_table')
rdd4.coalesce(1).saveAsTextFile("file:///home/talentum/whitehouse")

